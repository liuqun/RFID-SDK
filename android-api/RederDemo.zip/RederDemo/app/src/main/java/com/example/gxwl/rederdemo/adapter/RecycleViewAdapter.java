package com.example.gxwl.rederdemo.adapter;


import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.gxwl.rederdemo.R;
import com.example.gxwl.rederdemo.entity.TagInfo;

import java.util.List;


public class RecycleViewAdapter extends RecyclerView.Adapter<RecycleViewAdapter.ViewHolder> {
    private List<TagInfo> mTagList;
    private Integer thisPosition = null;

    public Integer getThisPosition() {
        return thisPosition;
    }

    public void setThisPosition(Integer thisPosition) {
        this.thisPosition = thisPosition;
    }


    class ViewHolder extends RecyclerView.ViewHolder {
        TextView index;
        TextView type;
        TextView epc;
        TextView tid;
        TextView rssi;
        TextView count;


        public ViewHolder(final View view) {
            super(view);
            index = (TextView) view.findViewById(R.id.index);
            type = (TextView) view.findViewById(R.id.type);
            epc = (TextView) view.findViewById(R.id.epc);
            tid = (TextView) view.findViewById(R.id.tid);
            rssi = (TextView) view.findViewById(R.id.rssi);
            count = (TextView) view.findViewById(R.id.count);
        }
    }

    public RecycleViewAdapter(List<TagInfo> list) {
        mTagList = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_item, parent, false);
        final RecycleViewAdapter.ViewHolder holder = new RecycleViewAdapter.ViewHolder(view);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TagInfo tag = mTagList.get(holder.getAdapterPosition());
                System.out.println(tag);
                setThisPosition(holder.getAdapterPosition());
                notifyDataSetChanged();

            }
        });

        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        TagInfo tag = mTagList.get(position);
        holder.index.setText(tag.getIndex().toString());
        holder.type.setText(tag.getType());
        holder.epc.setText(tag.getEpc());
        holder.tid.setText(tag.getTid());
        holder.rssi.setText(tag.getRssi());
        holder.count.setText(tag.getCount().toString());
        if (getThisPosition() != null && position == getThisPosition()) {
            holder.index.setBackgroundColor(Color.rgb(135, 206, 235));
            holder.type.setBackgroundColor(Color.rgb(135, 206, 235));
            holder.tid.setBackgroundColor(Color.rgb(135, 206, 235));
            holder.epc.setBackgroundColor(Color.rgb(135, 206, 235));
            holder.count.setBackgroundColor(Color.rgb(135, 206, 235));
            holder.rssi.setBackgroundColor(Color.rgb(135, 206, 235));
        } else {
            holder.index.setBackgroundColor(Color.WHITE);
            holder.type.setBackgroundColor(Color.WHITE);
            holder.tid.setBackgroundColor(Color.WHITE);
            holder.epc.setBackgroundColor(Color.WHITE);
            holder.count.setBackgroundColor(Color.WHITE);
            holder.rssi.setBackgroundColor(Color.WHITE);
        }
    }

    @Override
    public int getItemCount() {
        return mTagList.size();
    }

    public void notifyData1(List<TagInfo> poiItemList) {
        if (poiItemList != null) {
            int previousSize = mTagList.size();
//            mTagList.clear();
//            notifyItemRangeRemoved(0, previousSize);
//            mTagList.addAll(poiItemList);
            mTagList = poiItemList;
//            notifyItemRangeChanged(0,poiItemList.size());
//            notifyItemRangeInserted(0, poiItemList.size());
            notifyDataSetChanged();
        }
    }

    public void notifyData(List<TagInfo> poiItemList) {
        if (poiItemList != null) {
            mTagList = poiItemList;
            notifyDataSetChanged();
        }
    }

}
