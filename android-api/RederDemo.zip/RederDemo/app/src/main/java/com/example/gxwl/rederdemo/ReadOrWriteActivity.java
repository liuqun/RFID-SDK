package com.example.gxwl.rederdemo;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.gxwl.rederdemo.adapter.RecycleViewAdapter;
import com.example.gxwl.rederdemo.entity.TagInfo;
import com.example.gxwl.rederdemo.util.ComputedPc;
import com.example.gxwl.rederdemo.util.DataUtils;
import com.example.gxwl.rederdemo.util.GlobalClient;
import com.example.gxwl.rederdemo.util.ToastUtils;
import com.gg.reader.api.dal.GClient;
import com.gg.reader.api.dal.HandlerGpiOver;
import com.gg.reader.api.dal.HandlerGpiStart;
import com.gg.reader.api.dal.HandlerTag6bLog;
import com.gg.reader.api.dal.HandlerTag6bOver;
import com.gg.reader.api.dal.HandlerTagEpcLog;
import com.gg.reader.api.dal.HandlerTagEpcOver;
import com.gg.reader.api.dal.HandlerTagGbLog;
import com.gg.reader.api.dal.HandlerTagGbOver;
import com.gg.reader.api.protocol.gx.EnumG;
import com.gg.reader.api.protocol.gx.LogAppGpiOver;
import com.gg.reader.api.protocol.gx.LogAppGpiStart;
import com.gg.reader.api.protocol.gx.LogBase6bInfo;
import com.gg.reader.api.protocol.gx.LogBase6bOver;
import com.gg.reader.api.protocol.gx.LogBaseEpcInfo;
import com.gg.reader.api.protocol.gx.LogBaseEpcOver;
import com.gg.reader.api.protocol.gx.LogBaseGbInfo;
import com.gg.reader.api.protocol.gx.LogBaseGbOver;
import com.gg.reader.api.protocol.gx.MsgBaseInventory6b;
import com.gg.reader.api.protocol.gx.MsgBaseInventoryEpc;
import com.gg.reader.api.protocol.gx.MsgBaseInventoryGb;
import com.gg.reader.api.protocol.gx.MsgBaseSetBaseband;
import com.gg.reader.api.protocol.gx.MsgBaseStop;
import com.gg.reader.api.protocol.gx.MsgBaseWrite6b;
import com.gg.reader.api.protocol.gx.MsgBaseWriteEpc;
import com.gg.reader.api.protocol.gx.MsgBaseWriteGb;
import com.gg.reader.api.protocol.gx.ParamEpcFilter;
import com.gg.reader.api.protocol.gx.ParamEpcReadTid;
import com.gg.reader.api.protocol.gx.ParamGbReadUserdata;
import com.gg.reader.api.utils.HexUtils;
import com.gg.reader.api.utils.StringUtils;


import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ReadOrWriteActivity extends AppCompatActivity {
    // region 组件变量
    @BindView(R.id.read)
    Button read;
    @BindView(R.id.stop)
    Button stop;
    @BindView(R.id.clean)
    Button clean;
    @BindView(R.id.selectAll)
    Button selectAll;
    @BindView(R.id.ant1)
    CheckBox ant1;
    @BindView(R.id.ant2)
    CheckBox ant2;
    @BindView(R.id.ant3)
    CheckBox ant3;
    @BindView(R.id.ant4)
    CheckBox ant4;
    @BindView(R.id.ant5)
    CheckBox ant5;
    @BindView(R.id.ant6)
    CheckBox ant6;
    @BindView(R.id.ant7)
    CheckBox ant7;
    @BindView(R.id.ant8)
    CheckBox ant8;
    private Map<String, CheckBox> checkBoxMap = new LinkedHashMap<String, CheckBox>();//checkBox集合
    @BindView(R.id.way)
    RadioGroup way;
    @BindView(R.id.type)
    RadioGroup type;
    @BindView(R.id.single)
    RadioButton single;
    @BindView(R.id.loop)
    RadioButton loop;
    @BindView(R.id.c)
    RadioButton c;
    @BindView(R.id.b)
    RadioButton b;
    @BindView(R.id.gb)
    RadioButton gb;
    @BindView(R.id.readCount)
    TextView readCount;
    @BindView(R.id.tagCount)
    TextView tagCount;
    @BindView(R.id.speed)
    TextView speed;
    @BindView(R.id.timeCount)
    TextView timeCount;
    @BindView(R.id.tabHead)
    LinearLayout tabHead;


    EditText w_epc;
    EditText w_tid;
    EditText w_pas;
    EditText w_len;
    EditText w_value;
    //6c
    EditText w_user_epc;
    EditText w_user_tid;
    EditText w_user_pas;
    EditText w_user_len;
    EditText w_user_value;
    //6b
    EditText w_6b_user_tid;
    EditText w_6b_user_start;
    EditText w_6b_user_value;
    //自定义写
    Spinner cus_mode;
    EditText cus_start;
    EditText cus_pas;
    EditText cus_epc;
    EditText cus_tid;
    EditText cus_user;
    //gb user write
    EditText w_gb_user_epc;
    EditText w_gb_user_pas;
    EditText w_gb_user_tid;
    EditText w_gb_user_start;
    Spinner write_gb_user_child;
    EditText w_gb_user_value;
    //gb epc write
    EditText w_gb_epc;
    EditText w_gb_pas;
    EditText w_gb_tid;
    EditText w_gb_len;
    EditText w_gb_value;

    // endregion

    private GClient client = GlobalClient.getClient();
    private boolean isClient = false;
    private Map<String, TagInfo> tagInfoMap = new LinkedHashMap<String, TagInfo>();//去重数据源
    private List<TagInfo> tagInfoList = new ArrayList<TagInfo>();//适配器所需数据源
    private Long index = 1l;//索引
    private RecycleViewAdapter adapter;
    private ParamEpcReadTid tidParam = null;
    private boolean[] isChecked = new boolean[]{false};//标识读tid
    private Handler mHandler = new Handler();
    private Runnable r = null;
    private int time = 0;
    private boolean isReader = false;
    private SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        isClient = getIntent().getBooleanExtra("isClient", false);
        if (isClient) {
            subHandler(GlobalClient.getClient());
        }
        initRecycleView();
        initCheckBox();
    }

    //初始化RecycleView
    public void initRecycleView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        RecyclerView rv = (RecyclerView) findViewById(R.id.recycle);
        rv.setLayoutManager(layoutManager);
        rv.addItemDecoration(new DividerItemDecoration(this, 1));
        adapter = new RecycleViewAdapter(tagInfoList);
        rv.setAdapter(adapter);
    }

    //订阅
    public void subHandler(GClient client) {
        client.onTagEpcLog = new HandlerTagEpcLog() {
            public void log(String readerName, LogBaseEpcInfo info) {
                if (null != info && 0 == info.getResult()) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Map<String, TagInfo> infoMap = pooled6cData(info);
                            tagInfoList.clear();
                            tagInfoList.addAll(infoMap.values());

                        }
                    });
                }
            }
        };
        client.onTagEpcOver = new HandlerTagEpcOver() {
            public void log(String readerName, LogBaseEpcOver info) {
                handlerStop.sendEmptyMessage(1);
            }
        };
        client.onTag6bLog = new HandlerTag6bLog() {
            public void log(String readerName, LogBase6bInfo info) {
//                System.out.println(info);
                if (null != info) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Map<String, TagInfo> infoMap = pooled6bData(info);
                            tagInfoList.clear();
                            tagInfoList.addAll(infoMap.values());
                        }
                    });
                }
            }
        };
        client.onTag6bOver = new HandlerTag6bOver() {
            public void log(String readerName, LogBase6bOver info) {
                handlerStop.sendEmptyMessage(1);
            }
        };
        client.onTagGbLog = new HandlerTagGbLog() {
            public void log(String readerName, LogBaseGbInfo info) {
                if (null != info && info.getResult() == 0) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Map<String, TagInfo> infoMap = pooledGbData(info);
                            tagInfoList.clear();
                            tagInfoList.addAll(infoMap.values());
                        }
                    });
                }

            }
        };
        client.onTagGbOver = new HandlerTagGbOver() {
            public void log(String readerName, LogBaseGbOver info) {
                handlerStop.sendEmptyMessage(new Message().what = 1);
            }
        };
        client.onGpiOver = new HandlerGpiOver() {
            @Override
            public void log(String s, LogAppGpiOver logAppGpiOver) {
                System.out.println(logAppGpiOver);
            }
        };
        client.onGpiStart = new HandlerGpiStart() {
            @Override
            public void log(String s, LogAppGpiStart logAppGpiStart) {
                System.out.println(logAppGpiStart);
            }
        };
    }

    //读卡
    @OnClick(R.id.read)
    public void readCard() {
        if (isClient) {
            if (!isReader) {
                if (type.getCheckedRadioButtonId() == R.id.c) {
                    MsgBaseInventoryEpc msg = new MsgBaseInventoryEpc();
                    msg.setAntennaEnable(getAnt());
                    if (way.getCheckedRadioButtonId() == R.id.single) {
                        msg.setInventoryMode(EnumG.InventoryMode_Single);
                    } else {
                        msg.setInventoryMode(EnumG.InventoryMode_Inventory);
                    }

                    if (isChecked[0]) {
                        tidParam = new ParamEpcReadTid();
                        tidParam.setMode(EnumG.ParamTidMode_Auto);
                        tidParam.setLen(6);
                        msg.setReadTid(tidParam);
                    } else {
                        tidParam = null;
                    }

                    client.sendSynMsg(msg);
                    initPane();
                    computedSpeed();
                    if (0x00 == msg.getRtCode()) {
                        ToastUtils.showText("开始读卡");
                        isReader = true;
                        System.out.println("MsgBaseInventoryEpc[OK].");
                    } else {
                        ToastUtils.showText(msg.getRtMsg());
                        handlerStop.sendEmptyMessage(1);
                    }
                } else if (type.getCheckedRadioButtonId() == R.id.b) {
                    MsgBaseInventory6b msg = new MsgBaseInventory6b();
                    msg.setAntennaEnable(getAnt());
                    if (way.getCheckedRadioButtonId() == R.id.single) {
                        msg.setInventoryMode(EnumG.InventoryMode_Single);
                    } else {
                        msg.setInventoryMode(EnumG.InventoryMode_Inventory);
                    }
                    msg.setArea(EnumG.ReadMode6b_Tid);
                    client.sendSynMsg(msg);
                    initPane();
                    computedSpeed();
                    if (0x00 == msg.getRtCode()) {
                        ToastUtils.showText("开始读卡");
                        isReader = true;
                        System.out.println("MsgBaseInventory6B[OK].");
                    } else {
                        ToastUtils.showText(msg.getRtMsg());
                        handlerStop.sendEmptyMessage(1);
                    }
                } else if (type.getCheckedRadioButtonId() == R.id.gb) {
                    MsgBaseInventoryGb msg = new MsgBaseInventoryGb();
                    msg.setAntennaEnable(getAnt());
                    if (way.getCheckedRadioButtonId() == R.id.single) {
                        msg.setInventoryMode(EnumG.InventoryMode_Single);
                    } else {
                        msg.setInventoryMode(EnumG.InventoryMode_Inventory);
                    }
                    if (isChecked[0]) {
                        ParamEpcReadTid tid = new ParamEpcReadTid();
                        tid.setMode(EnumG.ParamTidMode_Auto);
                        tid.setLen(6);
                        msg.setReadTid(tid);
                    }

                    client.sendSynMsg(msg);
                    initPane();
                    computedSpeed();
                    if (0x00 == msg.getRtCode()) {
                        ToastUtils.showText("开始读卡");
                        isReader = true;
                        System.out.println("MsgBaseInventoryGB[OK].");
                    } else {
                        ToastUtils.showText(msg.getRtMsg());
                        handlerStop.sendEmptyMessage(1);
                    }
                }
            } else {
                ToastUtils.showText("请先停止读卡");
            }
        } else {
            ToastUtils.showText("未连接");
        }
    }

    //停止
    @OnClick(R.id.stop)
    public void stopRead() {
        if (isClient) {
            MsgBaseStop msgStop = new MsgBaseStop();
            client.sendSynMsg(msgStop);
            if (0x00 == msgStop.getRtCode()) {
                isReader = false;
                ToastUtils.showText("停止成功");
            } else {
                ToastUtils.showText("停止失败");
            }
        } else {
            ToastUtils.showText("未连接");
        }
    }

    //清屏
    @OnClick(R.id.clean)
    public void cleanData() {
        if (isClient) {
            initPane();
        } else {
            ToastUtils.showText("未连接");
        }
    }

    //去重6C
    public Map<String, TagInfo> pooled6cData(LogBaseEpcInfo info) {
        if (tagInfoMap.containsKey(info.getTid() + info.getEpc())) {
            TagInfo tagInfo = tagInfoMap.get(info.getTid() + info.getEpc());
            Long count = tagInfoMap.get(info.getTid() + info.getEpc()).getCount();
            count++;
            tagInfo.setRssi(info.getRssi() + "");
            tagInfo.setCount(count);
            tagInfoMap.put(info.getTid() + info.getEpc(), tagInfo);
        } else {
            TagInfo tag = new TagInfo();
            tag.setIndex(index);
            tag.setType("6C");
            tag.setEpc(info.getEpc());
            tag.setCount(1l);
            tag.setTid(info.getTid());
            tag.setRssi(info.getRssi() + "");
            tagInfoMap.put(info.getTid() + info.getEpc(), tag);
            index++;
        }

        return tagInfoMap;
    }

    //去重6B
    public Map<String, TagInfo> pooled6bData(LogBase6bInfo info) {
        if (tagInfoMap.containsKey(info.getTid())) {
            TagInfo tagInfo = tagInfoMap.get(info.getTid());
            Long count = tagInfoMap.get(info.getTid()).getCount();
            count++;
            tagInfo.setRssi(info.getRssi() + "");
            tagInfo.setCount(count);
            tagInfoMap.put(info.getTid(), tagInfo);
        } else {
            TagInfo tag = new TagInfo();
            tag.setIndex(index);
            tag.setType("6B");
            tag.setCount(1l);
            if (info.getTid() != null) {
                tag.setTid(info.getTid());
            }
            tag.setRssi(info.getRssi() + "");
            tagInfoMap.put(info.getTid(), tag);
            index++;
        }
        return tagInfoMap;
    }

    //去重GB
    public Map<String, TagInfo> pooledGbData(LogBaseGbInfo info) {
        if (tagInfoMap.containsKey(info.getTid() + info.getEpc())) {
            TagInfo tagInfo = tagInfoMap.get(info.getTid() + info.getEpc());
            Long count = tagInfoMap.get(info.getTid() + info.getEpc()).getCount();
            count++;
            tagInfo.setRssi(info.getRssi() + "");
            tagInfo.setCount(count);
            tagInfoMap.put(info.getTid() + info.getEpc(), tagInfo);
        } else {
            TagInfo tag = new TagInfo();
            tag.setIndex(index);
            tag.setType("GB");
            tag.setEpc(info.getEpc());
            tag.setCount(1l);
            tag.setTid(info.getTid());
            tag.setRssi(info.getRssi() + "");
            tagInfoMap.put(info.getTid() + info.getEpc(), tag);
            index++;
        }
        return tagInfoMap;
    }

    //程序此界面
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isClient) {
            if (isReader) {
                MsgBaseStop stop = new MsgBaseStop();
                client.sendSynMsg(stop);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    // 菜单的监听方法
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.single:
                MsgBaseSetBaseband single = new MsgBaseSetBaseband();
                single.setqValue(0);
                GlobalClient.getClient().sendSynMsg(single);
                if (0x00 == single.getRtCode()) {
                    ToastUtils.showText("设置成功");
                } else {
                    ToastUtils.showText(single.getRtMsg());
                }
                break;
            case R.id.much:
                MsgBaseSetBaseband much = new MsgBaseSetBaseband();
                much.setqValue(4);
                GlobalClient.getClient().sendSynMsg(much);
                if (0x00 == much.getRtCode()) {
                    ToastUtils.showText("设置成功");
                } else {
                    ToastUtils.showText(much.getRtMsg());
                }
                break;
            default:
                break;
        }
        return true;

    }

    //全选
    @OnClick(R.id.selectAll)
    public void setSelectAll() {
        int checkTrue = 0;
        for (String checkBox : checkBoxMap.keySet()) {
            if (!checkBoxMap.get(checkBox).isChecked()) {
                checkBoxMap.get(checkBox).setChecked(true);
                selectAll.setText("取消全选");
            } else {
                checkTrue++;
            }
        }
        if (checkTrue == 8) {
            for (String checkBox : checkBoxMap.keySet()) {
                checkBoxMap.get(checkBox).setChecked(false);
                selectAll.setText("全选");
            }
        }
    }

    @OnClick(R.id.tabHead)
    public void getTabHead() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("读取类型:")
                .setMultiChoiceItems(new String[]{"读TID"}, isChecked, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                        System.out.println(which + "--" + isChecked);
                    }
                })
                .setPositiveButton("确定", null)
                .setNegativeButton("取消", null)
                .show();
        //修改“确认”、“取消”按钮的字体大小
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextSize(26);
        dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextSize(26);
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.rgb(0, 87, 75));
        dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.rgb(0, 87, 75));
        try {
            Field mAlert = AlertDialog.class.getDeclaredField("mAlert");
            mAlert.setAccessible(true);
            Object mAlertController = mAlert.get(dialog);
            //通过反射修改title字体大小和颜色
            Field mTitle = mAlertController.getClass().getDeclaredField("mTitleView");
            mTitle.setAccessible(true);
            TextView mTitleView = (TextView) mTitle.get(mAlertController);
            mTitleView.setTextSize(30);
            mTitleView.setTextColor(Color.rgb(0, 87, 75));
            //通过反射修改message字体大小和颜色
//            Field mMessage = mAlertController.getClass().getDeclaredField("mMessageView");
//            mMessage.setAccessible(true);
//            TextView mMessageView = (TextView) mMessage.get(mAlertController);
//            mMessageView.setTextSize(28);
//            mTitleView.setTextColor(Color.rgb(0, 87, 75));
        } catch (IllegalAccessException e1) {
            e1.printStackTrace();
        } catch (NoSuchFieldException e2) {
            e2.printStackTrace();
        }
    }


    //初始化checkBox监听
    private void initCheckBox() {
        ant1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                System.out.println("ant1" + "--------" + isChecked);
                ant1.setChecked(isChecked);
                if (!isChecked) {
                    selectAll.setText("全选");
                }
                checkBoxMap.put("ant1", ant1);
            }
        });
        checkBoxMap.put("ant1", ant1);
        ant2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                System.out.println("ant2" + "--------" + isChecked);
                ant2.setChecked(isChecked);
                if (!isChecked) {
                    selectAll.setText("全选");
                }
                checkBoxMap.put("ant2", ant2);
            }
        });
        checkBoxMap.put("ant2", ant2);
        ant3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                System.out.println("ant3" + "--------" + isChecked);
                ant3.setChecked(isChecked);
                if (!isChecked) {
                    selectAll.setText("全选");
                }
                checkBoxMap.put("ant3", ant3);
            }
        });
        checkBoxMap.put("ant3", ant3);
        ant4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                System.out.println("ant4" + "--------" + isChecked);
                ant4.setChecked(isChecked);
                if (!isChecked) {
                    selectAll.setText("全选");
                }
                checkBoxMap.put("ant4", ant4);
            }
        });
        checkBoxMap.put("ant4", ant4);
        ant5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                System.out.println("ant5" + "--------" + isChecked);
                ant5.setChecked(isChecked);
                if (!isChecked) {
                    selectAll.setText("全选");
                }
                checkBoxMap.put("ant5", ant5);
            }
        });
        checkBoxMap.put("ant5", ant5);
        ant6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                System.out.println("ant6" + "--------" + isChecked);
                ant6.setChecked(isChecked);
                if (!isChecked) {
                    selectAll.setText("全选");
                }
                checkBoxMap.put("ant6", ant6);
            }
        });
        checkBoxMap.put("ant6", ant6);
        ant7.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                System.out.println("ant7" + "--------" + isChecked);
                ant7.setChecked(isChecked);
                if (!isChecked) {
                    selectAll.setText("全选");
                }
                checkBoxMap.put("ant7", ant7);
            }
        });
        checkBoxMap.put("ant7", ant7);
        ant8.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                System.out.println("ant8" + "--------" + isChecked);
                ant8.setChecked(isChecked);
                if (!isChecked) {
                    selectAll.setText("全选");
                }
                checkBoxMap.put("ant8", ant8);
            }
        });
        checkBoxMap.put("ant8", ant8);
    }

    //获取天线
    private long getAnt() {
        StringBuffer buffer = new StringBuffer();
        for (CheckBox box : checkBoxMap.values())
            if (box.isChecked()) {
                buffer.append(1);
            } else {
                buffer.append(0);
            }
        return Long.valueOf(buffer.reverse().toString(), 2);
    }

    //一秒刷新计算
    private void computedSpeed() {
        Map<String, Long> rateMap = new Hashtable<String, Long>();
        r = new Runnable() {
            @Override
            public void run() {
                String toTime = secToTime(++time);
                timeCount.setText(toTime + " (s)");
                long before = 0;
                long after = 0;
                Long afterValue = rateMap.get("after");
                if (null != afterValue) {
                    before = afterValue;
                }
                adapter.notifyData(tagInfoList);
                readCount.setText(getReadCount(tagInfoList) + "");
                tagCount.setText(tagInfoList.size() + "");
                rateMap.put("after", Long.valueOf(readCount.getText().toString()));
                after = Long.valueOf(readCount.getText().toString());
                if (after >= before) {
                    long rateValue = after - before;
                    speed.setText(rateValue + " (t/s)");
                }
                //每隔1s循环执行run方法
                mHandler.postDelayed(this, 1000);

            }
        };
        //延迟一秒执行
        mHandler.postDelayed(r, 1000);
    }

    //初始化面板
    private void initPane() {
        index = 1l;
        time = 0;
        tagInfoMap.clear();
        tagInfoList.clear();
        adapter.notifyData(tagInfoList);
        tagCount.setText(0 + "");
        readCount.setText(0 + "");
        timeCount.setText("00:00:00" + " (s)");
        speed.setText(0 + " (t/s)");
        adapter.setThisPosition(null);
    }

    //更新面板
    private void upDataPane() {
        adapter.notifyData(tagInfoList);
        readCount.setText(getReadCount(tagInfoList) + "");
        tagCount.setText(tagInfoList.size() + "");
    }

    //获取读取总次数
    private long getReadCount(List<TagInfo> tagInfoList) {
        long readCount = 0;
        for (int i = 0; i < tagInfoList.size(); i++) {
            readCount += tagInfoList.get(i).getCount();
        }
        return readCount;
    }

    //格式化时间
    public String secToTime(long time) {
        formatter.setTimeZone(TimeZone.getTimeZone("GMT+00:00"));
        time = time * 1000;
        String hms = formatter.format(time);
        return hms;
    }

    //写EPC
    @OnClick(R.id.fab_epc)
    public void writeEPC() {
        if (adapter.getThisPosition() != null) {
            if (type.getCheckedRadioButtonId() == R.id.c) {
                View writeView = getLayoutInflater().inflate(R.layout.write_epc, null, false);
                w_epc = writeView.findViewById(R.id.w_epc);
                w_tid = writeView.findViewById(R.id.w_tid);
                w_pas = writeView.findViewById(R.id.w_pas);
                w_len = writeView.findViewById(R.id.w_len);
                w_value = writeView.findViewById(R.id.w_value);
                AlertDialog.Builder writeDialog = new AlertDialog.Builder(ReadOrWriteActivity.this);
                writeDialog.setCancelable(false);
                writeDialog.setView(writeView);
                writeDialog.setPositiveButton("OK", null);
                writeDialog.setNegativeButton("Cancel", null);
                AlertDialog dialog = writeDialog.create();
                dialog.show();
                dialog.getWindow().setLayout((int) getResources().getDimension(R.dimen.layout_width_400), LinearLayout.LayoutParams.WRAP_CONTENT);
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        MsgBaseWriteEpc msg = new MsgBaseWriteEpc();
                        //天线
                        msg.setAntennaEnable(getAnt());
                        //数据区 0保留区 1EPC区 2TID区 3用户数据区
                        msg.setArea(EnumG.WriteArea_Epc);
                        //字起始地址 第0个为CRC，不可写
                        msg.setStart(1);
                        //写入内容
                        String content = ComputedPc.getPc(ComputedPc.getEPCLength(w_value)) + DataUtils.padLeft(w_value.getText().toString().trim().toUpperCase(), 4 * ComputedPc.getEPCLength(w_value), '0');
                        if (!StringUtils.isNullOfEmpty(content)) {
                            msg.setBwriteData(HexUtils.hexString2Bytes(content));
                        }
                        //选择写入参数
                        ParamEpcFilter filter = new ParamEpcFilter();
                        if (!StringUtils.isNullOfEmpty(w_tid.getText().toString().trim())) {
                            filter.setArea(EnumG.ParamFilterArea_TID);
                            filter.setHexData(w_tid.getText().toString().trim());
                            filter.setBitStart(0);
                            filter.setBitLength(w_tid.getText().toString().length() * 4);
                        } else {
                            filter.setArea(EnumG.ParamFilterArea_EPC);
                            filter.setHexData(w_epc.getText().toString().trim());
                            filter.setBitStart(32);
                            filter.setBitLength(w_epc.getText().toString().length() * 4);
                        }
                        msg.setFilter(filter);
                        //密码
                        String writeEPCPassword = w_pas.getText().toString();
                        msg.setHexPassword(writeEPCPassword);
                        //发送指令
                        client.sendSynMsg(msg);
                        if (0x00 == msg.getRtCode()) {
                            ToastUtils.showText("写入成功");
                        } else {
                            ToastUtils.showText(msg.getRtMsg());
                        }
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.cancel();
                    }
                });
                w_epc.setText(tagInfoList.get(adapter.getThisPosition()).getEpc());
                w_tid.setText(tagInfoList.get(adapter.getThisPosition()).getTid());
                w_value.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        System.out.println("onTextChanged" + s);
                        String taEPCDataText = s.toString().trim();
                        int iLength = 0;
                        if (taEPCDataText.length() % 4 == 0) {
                            iLength = taEPCDataText.length() / 4;
                        } else if (taEPCDataText.length() % 4 > 0) {
                            iLength = taEPCDataText.length() / 4 + 1;
                        }
                        w_len.setText(iLength + "");
                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                    }
                });
            } else if (type.getCheckedRadioButtonId() == R.id.b) {
                ToastUtils.showText(getResources().getString(R.string.not_sup_epc));
            } else if (type.getCheckedRadioButtonId() == R.id.gb) {
                View writeView = getLayoutInflater().inflate(R.layout.writegb_epc, null, false);
                w_gb_epc = writeView.findViewById(R.id.w_gb_epc);
                w_gb_pas = writeView.findViewById(R.id.w_gb_pas);
                w_gb_tid = writeView.findViewById(R.id.w_gb_tid);
                w_gb_len = writeView.findViewById(R.id.w_gb_len);
                w_gb_value = writeView.findViewById(R.id.w_gb_value);
                TagInfo tagInfo = tagInfoList.get(adapter.getThisPosition());
                AlertDialog.Builder writeDialog = new AlertDialog.Builder(ReadOrWriteActivity.this);
                writeDialog.setCancelable(false);
                writeDialog.setView(writeView);
                writeDialog.setPositiveButton("OK", null);
                writeDialog.setNegativeButton("Cancel", null);
                AlertDialog dialog = writeDialog.create();
                dialog.show();
                dialog.getWindow().setLayout((int) getResources().getDimension(R.dimen.layout_width_400), LinearLayout.LayoutParams.WRAP_CONTENT);
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!StringUtils.isNullOfEmpty(w_gb_value.getText().toString())) {
                            MsgBaseWriteGb msg = new MsgBaseWriteGb();
                            //天线
                            msg.setAntennaEnable(getAnt());
                            //数据区 0x10标签编码区epc 0x20标签安全区 0x30~0x3F用户子区
                            msg.setArea(0x10);
                            //字起始地址
                            msg.setStart(0);
                            //数据内容
                            int epcLength = ComputedPc.getEPCLength(w_gb_value);
                            String pc = ComputedPc.getGbPc(epcLength);
                            String epcData = DataUtils.padLeft(w_gb_value.getText().toString().trim().toUpperCase(), 4 * epcLength, '0');
                            String content = pc + epcData;
                            msg.setHexWriteData(content);

                            //选择写入参数
                            ParamEpcFilter filter = new ParamEpcFilter();
                            if (!StringUtils.isNullOfEmpty(tagInfo.getTid())) {
                                filter.setArea(0x00);
                                filter.setBitStart(0);
                                filter.setBitLength(tagInfo.getTid().length() * 4);
                                filter.setHexData(tagInfo.getTid());
                            } else {
                                filter.setArea(0x10);
                                filter.setBitStart(16);
                                filter.setBitLength(tagInfo.getEpc().length() * 4);
                                filter.setHexData(tagInfo.getEpc());
                            }
                            msg.setFilter(filter);

                            //密码
                            msg.setHexPassword(w_gb_pas.getText().toString().trim());
                            //发送指令
                            client.sendSynMsg(msg);
                            if (0x00 == msg.getRtCode()) {
                                dialog.cancel();
                                ToastUtils.showText("Write Success");
                            } else {
                                ToastUtils.showText(msg.getRtMsg());
                            }
                        } else {
                            ToastUtils.showText("Not Null");
                        }
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.cancel();
                    }
                });
                w_gb_epc.setText(tagInfo.getEpc());
                w_gb_tid.setText(tagInfo.getTid());
                w_gb_value.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        String taEPCDataText = s.toString().trim();
                        int iLength = 0;
                        if (taEPCDataText.length() % 4 == 0) {
                            iLength = taEPCDataText.length() / 4;
                        } else if (taEPCDataText.length() % 4 > 0) {
                            iLength = taEPCDataText.length() / 4 + 1;
                        }
                        w_gb_len.setText(iLength + "");
                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                    }
                });
            }
        } else {
            ToastUtils.showText("未选中标签");
        }
    }

    //写用户区
    @OnClick(R.id.fab_user)
    public void writeUser() {
        if (adapter.getThisPosition() != null) {
            if (type.getCheckedRadioButtonId() == R.id.c) {
                View writeView = getLayoutInflater().inflate(R.layout.write6c_user, null, false);
                w_user_epc = writeView.findViewById(R.id.w_user_epc);
                w_user_tid = writeView.findViewById(R.id.w_user_tid);
                w_user_pas = writeView.findViewById(R.id.w_user_pas);
                w_user_len = writeView.findViewById(R.id.w_user_len);
                w_user_value = writeView.findViewById(R.id.w_user_value);
                AlertDialog.Builder writeDialog = new AlertDialog.Builder(ReadOrWriteActivity.this);
                writeDialog.setCancelable(false);
                writeDialog.setView(writeView);
                writeDialog.setPositiveButton("OK", null);
                writeDialog.setNegativeButton("Cancel", null);
                AlertDialog dialog = writeDialog.create();
                dialog.show();
                dialog.getWindow().setLayout((int) getResources().getDimension(R.dimen.layout_width_400), LinearLayout.LayoutParams.WRAP_CONTENT);
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        MsgBaseWriteEpc msg = new MsgBaseWriteEpc();
                        //天线
                        msg.setAntennaEnable(getAnt());
                        //数据区 0保留区 1EPC区 2TID区 3用户数据区
                        msg.setArea(EnumG.WriteArea_Userdata);
                        //字起始地址
                        String start = w_user_len.getText().toString();
                        if (null != start) {
                            msg.setStart(Integer.parseInt(start));
                        }
                        //数据内容

                        String userData = w_user_value.getText().toString().trim();
                        int length = ComputedPc.getEPCLength(w_user_value);
                        String s = DataUtils.padLeft(userData, 4 * length, '0');
                        if (!StringUtils.isNullOfEmpty(s)) {
                            msg.setHexWriteData(s);
                        }
                        //选择写入参数
                        ParamEpcFilter filter = new ParamEpcFilter();
                        if (!StringUtils.isNullOfEmpty(w_user_tid.getText().toString().trim())) {
                            filter.setArea(EnumG.ParamFilterArea_TID);
                            filter.setHexData(w_user_tid.getText().toString().trim());
                            filter.setBitLength(w_user_tid.getText().toString().length() * 4);
                            filter.setBitStart(0);
                        } else {
                            filter.setArea(EnumG.ParamFilterArea_EPC);
                            filter.setHexData(w_user_epc.getText().toString().trim());
                            filter.setBitLength(w_user_epc.getText().toString().length() * 4);
                            filter.setBitStart(32);
                        }
                        msg.setFilter(filter);

                        //密码
                        String writeEPCPassword = w_user_pas.getText().toString().trim();
                        msg.setHexPassword(writeEPCPassword);

                        client.sendSynMsg(msg);
                        if (0x00 == msg.getRtCode()) {
                            ToastUtils.showText("6C写入成功");
                        } else {
                            ToastUtils.showText("msg.getRtMsg()");
                        }
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.cancel();
                    }
                });
                w_user_epc.setText(tagInfoList.get(adapter.getThisPosition()).getEpc());
                w_user_tid.setText(tagInfoList.get(adapter.getThisPosition()).getTid());
            } else if (type.getCheckedRadioButtonId() == R.id.b) {
                View writeView = getLayoutInflater().inflate(R.layout.write6b_user, null, false);
                w_6b_user_tid = writeView.findViewById(R.id.w_6b_user_tid);
                w_6b_user_start = writeView.findViewById(R.id.w_6b_user_start);
                w_6b_user_value = writeView.findViewById(R.id.w_6b_user_value);
                AlertDialog.Builder writeDialog = new AlertDialog.Builder(ReadOrWriteActivity.this);
                writeDialog.setCancelable(false);
                writeDialog.setView(writeView);
                writeDialog.setPositiveButton("OK", null);
                writeDialog.setNegativeButton("Cancel", null);
                AlertDialog dialog = writeDialog.create();
                dialog.show();
                dialog.getWindow().setLayout((int) getResources().getDimension(R.dimen.layout_width_400), LinearLayout.LayoutParams.WRAP_CONTENT);
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        MsgBaseWrite6b msg = new MsgBaseWrite6b();
                        //天线
                        msg.setAntennaEnable((long) getAnt());
                        //待写标签的TID
                        msg.setHexMatchTid(w_6b_user_tid.getText().toString().trim());
                        //起始地址
                        String toWrite6bStartAdd = w_6b_user_start.getText().toString().trim();
                        if (null != toWrite6bStartAdd) {
                            msg.setStart(Integer.parseInt(toWrite6bStartAdd));
                        }
                        //数据内容
                        String userData = w_6b_user_value.getText().toString().trim();
                        int length = ComputedPc.getEPCLength(w_6b_user_value);
                        String s = DataUtils.padLeft(userData, 2 * length, '0');
                        if (null != s) {
                            msg.setHexWriteData(s);
                        }
                        //发送指令
                        client.sendSynMsg(msg);
                        if (0x00 == msg.getRtCode()) {
                            dialog.cancel();
                            ToastUtils.showText("Write Success");
                        } else {
                            ToastUtils.showText(msg.getRtMsg());
                        }
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.cancel();
                    }
                });
                w_6b_user_tid.setText(tagInfoList.get(adapter.getThisPosition()).getTid());
            } else if (type.getCheckedRadioButtonId() == R.id.gb) {
                View writeView = getLayoutInflater().inflate(R.layout.writegb_user, null, false);
                w_gb_user_epc = writeView.findViewById(R.id.w_gb_user_epc);
                w_gb_user_pas = writeView.findViewById(R.id.w_gb_user_pas);
                w_gb_user_tid = writeView.findViewById(R.id.w_gb_user_tid);
                w_gb_user_start = writeView.findViewById(R.id.w_gb_user_start);
                write_gb_user_child = writeView.findViewById(R.id.write_gb_user_child);
                w_gb_user_value = writeView.findViewById(R.id.w_gb_user_value);
                TagInfo tagInfo = tagInfoList.get(adapter.getThisPosition());
                AlertDialog.Builder writeDialog = new AlertDialog.Builder(ReadOrWriteActivity.this);
                writeDialog.setCancelable(false);
                writeDialog.setView(writeView);
                writeDialog.setPositiveButton("OK", null);
                writeDialog.setNegativeButton("Cancel", null);
                AlertDialog dialog = writeDialog.create();
                dialog.show();
                dialog.getWindow().setLayout((int) getResources().getDimension(R.dimen.layout_width_400), LinearLayout.LayoutParams.WRAP_CONTENT);
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        MsgBaseWriteGb msg = new MsgBaseWriteGb();
                        //天线
                        msg.setAntennaEnable((long) getAnt());
                        //数据区
                        msg.setArea(getUserDataChild());
                        //起始地址
                        msg.setStart(Integer.parseInt(w_gb_user_start.getText().toString()));
                        //密码
                        msg.setHexPassword(w_gb_user_pas.getText().toString());
                        //数据内容
                        String userData = w_gb_user_value.getText().toString().trim();
                        int length = ComputedPc.getEPCLength(w_gb_user_value);
                        String s = DataUtils.padLeft(userData, 4 * length, '0');
                        if (null != s) {
                            msg.setHexWriteData(s);
                        }
                        //选择写入参数 信息区=TID 编码区=EPC
                        ParamEpcFilter filter = new ParamEpcFilter();
                        if (!StringUtils.isNullOfEmpty(w_gb_user_tid.getText().toString())) {
                            filter.setArea(0x00);//信息区
                            filter.setBitStart(0);
                            filter.setBitLength(w_gb_user_tid.getText().length() * 4);
                            filter.setHexData(w_gb_user_tid.getText().toString());
                        } else {
                            filter.setArea(0x10);//编码区
                            filter.setBitStart(16);//0100+data
                            filter.setBitLength(w_gb_user_epc.getText().length() * 4);
                            filter.setHexData(w_gb_user_epc.getText().toString());
                        }
                        msg.setFilter(filter);
                        //发送指令
                        client.sendSynMsg(msg);
                        if (0x00 == msg.getRtCode()) {
                            dialog.cancel();
                            ToastUtils.showText("Write Success");
                        } else {
                            ToastUtils.showText(msg.getRtMsg());
                        }
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.cancel();
                    }
                });

                w_gb_user_epc.setText(tagInfo.getEpc());
                w_gb_user_tid.setText(tagInfo.getTid());
            }
        } else {
            ToastUtils.showText("未选中标签");
        }
    }

    //转换16进制用户子区为10进制
    public Integer getUserDataChild() {
        int userChild = 48;
        int selectedIndex = write_gb_user_child.getSelectedItemPosition();
        userChild = selectedIndex + (3 * 16);
        return userChild;
    }

    //自定义写
    @OnClick(R.id.fab_cus)
    public void writeCus() {
        if (adapter.getThisPosition() != null) {
            Intent intent = new Intent(this, DialogCusActivity.class);
            intent.putExtra("Tag", tagInfoList.get(adapter.getThisPosition()));
            intent.putExtra("Ant", getAnt());
            intent.putExtra("Type", type.getCheckedRadioButtonId());
            startActivity(intent);
        } else {
            ToastUtils.showText("未选中标签");
        }
    }

    final Handler handlerStop = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    mHandler.removeCallbacks(r);
                    upDataPane();
                    isReader = false;
                    break;
            }
            super.handleMessage(msg);
        }
    };

}
