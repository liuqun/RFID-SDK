package com.example.gxwl.rederdemo;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewStub;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;


import com.example.gxwl.rederdemo.util.GlobalClient;
import com.example.gxwl.rederdemo.util.SerialPortFinder;
import com.example.gxwl.rederdemo.util.ToastUtils;
import com.gg.reader.api.utils.ThreadPoolUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;


public class EntryActivity extends AppCompatActivity {

    EditText tcp_param;
    private boolean isClient = false;
    @BindView(R.id.connect_param)
    TextView connect_param;
    ViewStub tcp_stub;
    Spinner connect_type;
    ViewStub rs232_android_stub;
    Spinner rs232_android_port;
    Spinner rs232_android_baud;
    private int conType = 0;
    SharedPreferences sp;
    SharedPreferences.Editor edit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.entry_layout);
        ButterKnife.bind(this);
        cusConnect();
        sp = getSharedPreferences("TCP_PARAM", Activity.MODE_PRIVATE);
    }


    //设备连接
    @OnClick(R.id.cusConnect)
    public void cusConnect() {
        final View writeView = getLayoutInflater().inflate(R.layout.connect, null, false);
        initViewStub(writeView);
        AlertDialog.Builder writeDialog = new AlertDialog.Builder(EntryActivity.this);
        writeDialog.setView(writeView);
        writeDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (!isClient) {
                    connect(connect_type);
                } else {
                    ToastUtils.showText("已连接，请勿重复连接");
                }
            }
        });

        AlertDialog dialog = writeDialog.create();
        dialog.show();
        dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
        //监听连接类型 初始化会执行
        connect_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        conType = 0;
                        tcp_stub.setVisibility(View.VISIBLE);
                        tcp_param = writeView.findViewById(R.id.tcp_param);
                        tcp_param.setText(sp.getString("tcp", "127.0.0.1:8160"));
                        rs232_android_stub.setVisibility(View.GONE);
                        break;
                    case 1:
                        conType = 1;
                        rs232_android_stub.setVisibility(View.VISIBLE);
                        initAndroidPorts(writeView);
                        tcp_stub.setVisibility(View.GONE);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    //2种连接
    //todo android 4 以上tcp通信需要在子线程，此示例demo中tcp仅适用于【读写器内部开发】
    //todo 高版本的android tcp开发 连接【openTcp】与发送指令【client.sendSynMsg()】都需要在子线程中
    //todo 直观简单的api示例可在提供的开发包中【java-api】文件夹内查看
    public void connect(Spinner spinner) {
        switch (spinner.getSelectedItemPosition()) {
            case 0:
                ThreadPoolUtils.run(new Runnable() {//此线程池为jar内封装工具类，高版本tcp开发可用此工具类
                    @Override
                    public void run() {
                        if (GlobalClient.getClient().openTcp(tcp_param.getText().toString().trim(), 0)) {
                            isClient = true;
                            edit = sp.edit();
                            edit.putString("tcp", tcp_param.getText().toString().trim());
                            edit.commit();
                            setConnect_param("Tcp " + tcp_param.getText().toString().trim());
                            ToastUtils.showLooperText(EntryActivity.this, "连接成功");
                        } else {
                            isClient = false;
                            setConnect_param("Tcp " + tcp_param.getText().toString().trim());
                            ToastUtils.showLooperText(EntryActivity.this, "连接失败");
                        }
                    }
                });
                break;
            case 1:
                String param = "/dev/" + rs232_android_port.getSelectedItem().toString().trim() + ":" + rs232_android_baud.getSelectedItem().toString().substring(0, rs232_android_baud.getSelectedItem().toString().indexOf("b")).trim();
                System.out.println(param);
                if (GlobalClient.getClient().openAndroidSerial(param, 1000)) {
                    isClient = true;
                    edit = sp.edit();
                    edit.putInt("dev", rs232_android_port.getSelectedItemPosition());
                    edit.commit();
                    setConnect_param("/dev/" + rs232_android_port.getSelectedItem() + ":" + rs232_android_baud.getSelectedItem());
                    ToastUtils.showText("连接成功");
                } else {
                    isClient = false;
                    setConnect_param("/dev/" + rs232_android_port.getSelectedItem() + ":" + rs232_android_baud.getSelectedItem());
                    ToastUtils.showText("连接失败");
                }
                break;
        }
    }

    @OnClick(R.id.readOrWrite)
    public void readOrWriteWay() {
        if (isClient) {
            Intent intent = new Intent(this, ReadOrWriteActivity.class);
            intent.putExtra("isClient", isClient);
            startActivity(intent);
        } else {
            ToastUtils.showText("未连接");
        }

    }

    //断开连接
    @OnClick(R.id.disConnect)
    public void disConnect() {
        if (isClient) {
            GlobalClient.getClient().close();
            isClient = false;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    connect_param.setText("已断开连接");
                    connect_param.setTextColor(getResources().getColor(R.color.IndianRed));
                }
            });
        } else {
            ToastUtils.showText("未连接");
        }
    }

    //设置连接状态
    public void setConnect_param(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isClient) {
                    connect_param.setText(msg + " Success");
                    connect_param.setTextColor(getResources().getColor(R.color.DodgerBlue));
                } else {
                    connect_param.setText(msg + " Fail");
                    connect_param.setTextColor(getResources().getColor(R.color.IndianRed));
                }
            }
        });
    }

    //初始化androidRs232连接参数
    public void initAndroidPorts(View view) {
        SerialPortFinder finder = new SerialPortFinder();
        List<String> devs = new ArrayList<>();
        for (String dev : finder.getAllDevices()) {
            devs.add(dev.substring(0, dev.indexOf("(")));
        }
        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(view.getContext(), R.layout.spinner_item, devs);
        adapter.setDropDownViewResource(R.layout.spinner_item);
        rs232_android_port = view.findViewById(R.id.rs232_android_port);
        rs232_android_port.setAdapter(adapter);
//        rs232_android_port.setSelection(sp.getInt("dev", 6));
        rs232_android_baud = view.findViewById(R.id.rs232_android_baud);
        rs232_android_baud.setSelection(2);

    }

    //初始化ViewStub
    public void initViewStub(View view) {
        connect_type = view.findViewById(R.id.connect_type);
        connect_type.setSelection(conType);
        tcp_stub = view.findViewById(R.id.tcp_stub);
        rs232_android_stub = view.findViewById(R.id.rs232_android_stub);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isClient) {
            Log.e("退出应用", "断开连接");
            GlobalClient.getClient().close();
        }
    }

}
